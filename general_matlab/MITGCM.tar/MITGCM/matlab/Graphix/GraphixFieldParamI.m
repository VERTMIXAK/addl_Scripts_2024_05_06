fractunitsI = '0-1';
fractrangeI = [0,1];
fractcontourI = [0:.1:1];

iceHunitsI = 'm';
iceHrangeI = [0,10];
iceHcontourI = [0:1:10];

snowHunitsI = 'm';
snowHrangeI = [0,2];
snowHcontourI = [0:0.2:2];

TsrfunitsI = 'C';
TsrfrangeI = [-30,0];
TsrfcontourI = [-30:2.5:0];

Tice1unitsI = 'C';
Tice1rangeI = [-12,0];
Tice1contourI = [-12:1:0];

Tice2unitsI = 'C';
Tice2rangeI = [-12,0];
Tice2contourI = [-12:1:0];

snowPrunitsI = 'kg/m2/s';
snowPrrangeI = [0,1e-5];
snowPrcontourI = [0:.1e-5:1e-5];

albedounitsI = '0-1';
albedorangeI = [0,1];
albedocontourI = [0:.1:1];

flx2ocunitsI = 'W/m2';
flx2ocrangeI = [-100,50];
flx2occontourI = [-100:10:50];

frw2ocunitsI = 'm/s';
frw2ocrangeI = [-3e-8,4e-8];
frw2occontourI = [-3e-8:.5e8:4e-8];