SunitsO = 'psu';
SrangeO = [30,37.5];
ScontourO = [30:.5:37.5];

TunitsO = 'C';
TrangeO = [-4,34];
%TcontourO = [-4:1:5,6:4:34];
TcontourO = [0:2:36];

ConvunitsO = '0-1';
ConvrangeO = [0,1];
ConvcontourO = [0:.05:1];

UunitsO = 'm/s';
UrangeO = [-1,1];
UcontourO = [-1:.1:1];

VunitsO = 'm/s';
VrangeO = [-.05,.05];
VcontourO = [-.05:.01:.05];

WunitsO = 'm/s';
WrangeO = [-2.5e-6,2.5e-6];
WcontourO = [-2.5e-6:.5e-6:2.5e-6];

PsiunitsO = 'Sv';
PsirangeO = [-70,70];
PsicontourO = [-70:10:70];

BolunitsO = 'Sv';
BolrangeO = [-70,70];
BolcontourO = [-70:10:70];

ResunitsO = 'Sv';
ResrangeO = [-70,70];
RescontourO = [-70:10:70];


ETAunitsO = 'm';
ETArangeO = [-8,3];
ETAcontourO = [-8:5:3];

TstdunitsO = 'K';
TstdrangeO = [0,5];
TstdcontourO = [0:0.5:5];

KEpriunitsO = 'm/s';
KEprirangeO = [0,.2];
KEpricontourO = [0:.01:.2];

ETAstdunitsO = 'hPa';
ETAstdrangeO = [0,18];
ETAstdcontourO = [0:1:18];

PhHyunitsO = '???';
PhHyrangeO = [-8000,4000];
PhHycontourO = [-8000:500:4000];