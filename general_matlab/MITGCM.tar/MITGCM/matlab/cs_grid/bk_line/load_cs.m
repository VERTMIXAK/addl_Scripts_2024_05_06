
% $Header: /u/gcmpack/MITgcm/utils/matlab/cs_grid/bk_line/load_cs.m,v 1.1 2005/09/15 16:46:28 jmc Exp $
% $Name: checkpoint62l $

%rac='res_ncepPC_K3a2/';

xcs=rdmds([rac,'XC']);
ycs=rdmds([rac,'YC']);
xcg=rdmds([rac,'XG']);
ycg=rdmds([rac,'YG']);
arc=rdmds([rac,'RAC']);
%msk=rdmds([rac,'hFacC']);

% dxc=rdmds([rac,'DXC']); 
% dyc=rdmds([rac,'DYC']); 
% dxg=rdmds([rac,'DXG']); 
% dyg=rdmds([rac,'DYG']); 

